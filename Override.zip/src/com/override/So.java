package com.override;

public class So {

	public static void ln(String s) {

		System.out.println(s);
	}

	public static void ln(int n) {

		System.out.println(n);
	}

	public static void p(String s) {

		System.out.print(s);
	}

}
