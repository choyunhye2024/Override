package com.override;

public class Son3 extends Father {

	void kimchi() {

		System.out.println("피자김치");
	}

}
