package com.override;

public class Son extends Father {

	void kimchi() {

		System.out.println("치즈김치");
	}

}
