package com.override;

public class Son2 extends Father {

	void kimchi() {

		System.out.println("감자 김치");
	}

}
