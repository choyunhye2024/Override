package com.override;

public class Monster {

	int hp;
	int attack;

	void attack(Player p) {

	}

}
