package com.override;

public class Player {

	int hp;
	String name;

	public Player(String name, int hp) {

		this.hp = hp;
		this.name = name;
	}

}
